function setup() {
  createCanvas(400, 400);
}


let xJogador1 = 0;
let xJogador2 = 0;

function draw() {
  background('#E91E2F');
  textSize(40);
  text("💋", xJogador1, 100); // emoji de beijinho
  text("🌙", xJogador2, 300); //emoji de lua
  rect(350, 0, 10, 400);
  xJogador1 += random(5);
  xJogador2 += random(5); 
 
}